package tugaspbo7;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class GUIPBO extends JFrame implements ActionListener {
    private JTextField txtJudul, txtAlur, txtPenokohan, txtAkting;
    private JButton btnTambah, btnUpdate, btnDelete, btnClear;
    private JTable table;
    private DefaultTableModel tableModel;

    public GUIPBO() {
        setTitle("Sistem Penilaian Film");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        String[] columnNames = {"Judul", "Alur", "Penokohan", "Akting", "Nilai"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel(new GridLayout(5, 2));

        inputPanel.add(new JLabel("Judul:"));
        txtJudul = new JTextField();
        inputPanel.add(txtJudul);

        inputPanel.add(new JLabel("Nilai Alur (1-5):"));
        txtAlur = new JTextField();
        inputPanel.add(txtAlur);

        inputPanel.add(new JLabel("Nilai Penokohan (1-5):"));
        txtPenokohan = new JTextField();
        inputPanel.add(txtPenokohan);

        inputPanel.add(new JLabel("Nilai Akting (1-5):"));
        txtAkting = new JTextField();
        inputPanel.add(txtAkting);

        btnTambah = new JButton("Tambah");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnClear = new JButton("Clear");

        btnTambah.addActionListener(this);
        btnUpdate.addActionListener(this);
        btnDelete.addActionListener(this);
        btnClear.addActionListener(this);

        inputPanel.add(btnTambah);
        inputPanel.add(btnUpdate);
        inputPanel.add(btnDelete);
        inputPanel.add(btnClear);

        panel.add(inputPanel, BorderLayout.EAST);

        add(panel);
        setVisible(true);
    }

    public static void main(String[] args) {
        new GUIPBO();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Implementasi logika untuk tombol tambah, update, delete, dan clear
    }
}
